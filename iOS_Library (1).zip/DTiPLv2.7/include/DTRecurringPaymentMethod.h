//
//  DTRecurringPaymentMethod.h
//  Datatrans
//
//  Created by Basil Achermann on 5/15/13.
//  Copyright 2013 iEffects GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DTPaymentMethod.h"


@interface DTRecurringPaymentMethod : DTPaymentMethod <NSCopying, NSCoding> {
@private
	NSString* _alias;
}

@property (nonatomic, copy) NSString* alias;

- (id)initWithPaymentMethod:(NSString *)method;

// Archiving / unarchiving helpers
+ (id)recurringPaymentMethodWithData:(NSData *)data;
- (NSData *)data;

@end
