//
//  DTAliasRequest.h
//  Datatrans
//
//  Created by Basil Achermann on 12/27/10.
//  Copyright 2010 iEffects GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DTCardPaymentMethod.h"

@interface DTAliasRequest : NSObject <NSCopying>

// hidden mode credit card alias request with/without verifying transaction
- (id)initWithMerchantId:(NSString *)merchantId
	   cardPaymentMethod:(DTCardPaymentMethod *)method
	verifyingTransaction:(BOOL)verify;

// standard mode alias request (with verifying transaction)
- (id)initWithMerchantId:(NSString *)merchantId paymentMethods:(NSArray *)paymentMethods;

@end
