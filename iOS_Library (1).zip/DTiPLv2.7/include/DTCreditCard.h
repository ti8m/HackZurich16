//
//  DTCreditCard.h
//  Datatrans
//
//  Created by Kaspar Rohrer on 8/11/10.
//  Copyright 2010 iEffects. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DTRecurringPaymentMethod.h"

@class DTPaymentMethodInfo;

@interface DTCreditCard : DTRecurringPaymentMethod<NSCopying, NSCoding> {
	NSUInteger _expMonth;
	NSUInteger _expYear;
	NSString* _maskedCC;
	NSString* _cardHolder;
}

@property (nonatomic, assign) NSUInteger expMonth;
@property (nonatomic, assign) NSUInteger expYear;
@property (nonatomic, copy) NSString* maskedCC;
@property (nonatomic, copy) NSString* cardHolder;

- (id)initWithPaymentMethod:(NSString *)method;

// Archiving / unarchiving helpers
+ (id)creditCardWithData:(NSData *)data;
- (NSData *)data;

@end
