//
//  DTSwissBillingPaymentInfo.h
//  datatrans-iphone
//
//  Created by bacherma on 06/07/15.
//  Copyright 2015 iEffects GmbH. All rights reserved.
//
//
//  Class for configuring SwissBilling payments. In the following example a payment is made with basket items:
//
//      DTAddress* address = [[DTAddress alloc] initWithFirstName:@"Johnny B." lastName:@"Good" street:@"Limmatquai" city:@"Zürich" zipCode:@"8001" countryCode:@"CH"];
//      DTDate* birthDate = [[DTDate alloc] initWithYear:1969 month:9 day:19];
//      DTSwissBillingPaymentInfo* info = [[DTSwissBillingPaymentInfo alloc] initWithCustomerAddress:address phone:@"+41584333034" email:@"eshop@example.com" birthDate:birthDate];
//      info.shippingAddress = address;
//
//      NSMutableArray* items = [NSMutableArray array];
//      DTBasketItem* item = [[DTBasketItem alloc] initWithId:@"1" name:@"name 1" grossPrice:1000 quantity:1];
//      [items addObject:item];
//      item = [[DTBasketItem alloc] initWithId:@"2" name:@"name 2" grossPrice:500 quantity:2];
//      [items addObject:item];
//      info.basketItems = items;
//
//      paymentController.paymentOptions.swissBillingPaymentInfo = info;
//

#import <Foundation/Foundation.h>
#import "DTAddress.h"
#import "DTDate.h"
#import "DTBasketItem.h"

@interface DTSwissBillingPaymentInfo : NSObject<NSCopying>

@property (nonatomic, copy) DTAddress* customerAddress;
@property (nonatomic, copy) NSString* phone;
@property (nonatomic, copy) NSString* email;
@property (nonatomic, retain) DTDate* birthDate;

@property (nonatomic, assign) NSInteger taxAmount;
@property (nonatomic, copy) NSString* customerId;
@property (nonatomic, copy) NSString* customerLanguage; // DE, FR, IT
@property (nonatomic, copy) DTAddress* shippingAddress;
@property (nonatomic, copy) NSArray* basketItems; // array of DTBasketItem* objects

- (id)initWithCustomerAddress:(DTAddress *)customerAddress phone:(NSString *)phone email:(NSString *)email birthDate:(DTDate *)birthDate;

@end
