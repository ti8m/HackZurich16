package ch.datatrans.payment.android;

import android.content.Context;

/**
 * Accessor for the Datatrans payment library's resources.
 */
public class ResourceProvider implements IResourceProvider {
	/**
	 * @see ch.datatrans.payment.android.IResourceProvider#getNWErrorButtonCancelText(android.content.Context)
	 */
	@Override
	public String getNWErrorButtonCancelText(Context context) {
		return context.getString(R.string.nw_error_button_cancel);
	}

	/**
	 * @see ch.datatrans.payment.android.IResourceProvider#getNWErrorButtonRetryText(android.content.Context)
	 */
	@Override
	public String getNWErrorButtonRetryText(Context context) {
		return context.getString(R.string.nw_error_button_retry);
	}

	/**
	 * @see ch.datatrans.payment.android.IResourceProvider#getNWErrorDialogMessageText(android.content.Context)
	 */
	@Override
	public String getNWErrorDialogMessageText(Context context) {
		return context.getString(R.string.nw_error_message);
	}

	/**
	 * @see ch.datatrans.payment.android.IResourceProvider#getNWErrorDialogTitleText(android.content.Context)
	 */
	@Override
	public String getNWErrorDialogTitleText(Context context) {
		return context.getString(R.string.nw_error_title);
	}

	/**
	 * @see ch.datatrans.payment.android.IResourceProvider#getNWIndicatorMessageText(android.content.Context)
	 */
	@Override
	public String getNWIndicatorMessageText(Context context) {
		return context.getString(R.string.nw_indicator_message);
	}

}
